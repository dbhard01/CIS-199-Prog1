﻿namespace Program1f
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lengthTotallbl = new System.Windows.Forms.Label();
            this.wallHeightlbl = new System.Windows.Forms.Label();
            this.doorNumberlbl = new System.Windows.Forms.Label();
            this.windowNumberlbl = new System.Windows.Forms.Label();
            this.coatNumberlbl = new System.Windows.Forms.Label();
            this.gallonsMinlbl = new System.Windows.Forms.Label();
            this.wallLengthtxt = new System.Windows.Forms.TextBox();
            this.wallHeighttxt = new System.Windows.Forms.TextBox();
            this.doorNumbertext = new System.Windows.Forms.TextBox();
            this.windowNumbertxt = new System.Windows.Forms.TextBox();
            this.coatNumbertxt = new System.Windows.Forms.TextBox();
            this.resultscalculatedbtn = new System.Windows.Forms.Button();
            this.paintMinlbl = new System.Windows.Forms.Label();
            this.gallonsToBuylbl = new System.Windows.Forms.Label();
            this.wholeGallonslbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lengthTotallbl
            // 
            this.lengthTotallbl.Location = new System.Drawing.Point(58, 64);
            this.lengthTotallbl.Name = "lengthTotallbl";
            this.lengthTotallbl.Size = new System.Drawing.Size(319, 23);
            this.lengthTotallbl.TabIndex = 0;
            this.lengthTotallbl.Text = "Enter the total length of all the walls(in feet):";
            // 
            // wallHeightlbl
            // 
            this.wallHeightlbl.Location = new System.Drawing.Point(60, 101);
            this.wallHeightlbl.Name = "wallHeightlbl";
            this.wallHeightlbl.Size = new System.Drawing.Size(279, 23);
            this.wallHeightlbl.TabIndex = 1;
            this.wallHeightlbl.Text = "Enter the height of the walls(in feet):";
            // 
            // doorNumberlbl
            // 
            this.doorNumberlbl.Location = new System.Drawing.Point(55, 141);
            this.doorNumberlbl.Name = "doorNumberlbl";
            this.doorNumberlbl.Size = new System.Drawing.Size(319, 23);
            this.doorNumberlbl.TabIndex = 2;
            this.doorNumberlbl.Text = "Enter the number of doors(non-neg int):";
            // 
            // windowNumberlbl
            // 
            this.windowNumberlbl.Location = new System.Drawing.Point(55, 180);
            this.windowNumberlbl.Name = "windowNumberlbl";
            this.windowNumberlbl.Size = new System.Drawing.Size(319, 23);
            this.windowNumberlbl.TabIndex = 3;
            this.windowNumberlbl.Text = "Enter the number of windows(non-neg int):";
            // 
            // coatNumberlbl
            // 
            this.coatNumberlbl.Location = new System.Drawing.Point(55, 222);
            this.coatNumberlbl.Name = "coatNumberlbl";
            this.coatNumberlbl.Size = new System.Drawing.Size(319, 23);
            this.coatNumberlbl.TabIndex = 4;
            this.coatNumberlbl.Text = "Enter the number of coats of paint (non-neg int):";
            // 
            // gallonsMinlbl
            // 
            this.gallonsMinlbl.Location = new System.Drawing.Point(52, 269);
            this.gallonsMinlbl.Name = "gallonsMinlbl";
            this.gallonsMinlbl.Size = new System.Drawing.Size(287, 23);
            this.gallonsMinlbl.TabIndex = 5;
            this.gallonsMinlbl.Text = "Minimum gallons of paint needed:";
            // 
            // wallLengthtxt
            // 
            this.wallLengthtxt.Location = new System.Drawing.Point(365, 65);
            this.wallLengthtxt.Name = "wallLengthtxt";
            this.wallLengthtxt.Size = new System.Drawing.Size(53, 22);
            this.wallLengthtxt.TabIndex = 6;
            // 
            // wallHeighttxt
            // 
            this.wallHeighttxt.Location = new System.Drawing.Point(365, 102);
            this.wallHeighttxt.Name = "wallHeighttxt";
            this.wallHeighttxt.Size = new System.Drawing.Size(53, 22);
            this.wallHeighttxt.TabIndex = 7;
            // 
            // doorNumbertext
            // 
            this.doorNumbertext.Location = new System.Drawing.Point(365, 138);
            this.doorNumbertext.Name = "doorNumbertext";
            this.doorNumbertext.Size = new System.Drawing.Size(53, 22);
            this.doorNumbertext.TabIndex = 8;
            // 
            // windowNumbertxt
            // 
            this.windowNumbertxt.Location = new System.Drawing.Point(365, 181);
            this.windowNumbertxt.Name = "windowNumbertxt";
            this.windowNumbertxt.Size = new System.Drawing.Size(53, 22);
            this.windowNumbertxt.TabIndex = 9;
            // 
            // coatNumbertxt
            // 
            this.coatNumbertxt.Location = new System.Drawing.Point(365, 223);
            this.coatNumbertxt.Name = "coatNumbertxt";
            this.coatNumbertxt.Size = new System.Drawing.Size(53, 22);
            this.coatNumbertxt.TabIndex = 10;
            // 
            // resultscalculatedbtn
            // 
            this.resultscalculatedbtn.Location = new System.Drawing.Point(217, 355);
            this.resultscalculatedbtn.Name = "resultscalculatedbtn";
            this.resultscalculatedbtn.Size = new System.Drawing.Size(122, 37);
            this.resultscalculatedbtn.TabIndex = 12;
            this.resultscalculatedbtn.Text = "Calculate ";
            this.resultscalculatedbtn.UseVisualStyleBackColor = true;
            this.resultscalculatedbtn.Click += new System.EventHandler(this.resultscalculatedbtn_Click);
            // 
            // paintMinlbl
            // 
            this.paintMinlbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paintMinlbl.Location = new System.Drawing.Point(278, 269);
            this.paintMinlbl.Name = "paintMinlbl";
            this.paintMinlbl.Size = new System.Drawing.Size(51, 23);
            this.paintMinlbl.TabIndex = 13;
            // 
            // gallonsToBuylbl
            // 
            this.gallonsToBuylbl.Location = new System.Drawing.Point(52, 303);
            this.gallonsToBuylbl.Name = "gallonsToBuylbl";
            this.gallonsToBuylbl.Size = new System.Drawing.Size(217, 23);
            this.gallonsToBuylbl.TabIndex = 14;
            this.gallonsToBuylbl.Text = "Number of whole gallons to buy:";
            // 
            // wholeGallonslbl
            // 
            this.wholeGallonslbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.wholeGallonslbl.Location = new System.Drawing.Point(278, 303);
            this.wholeGallonslbl.Name = "wholeGallonslbl";
            this.wholeGallonslbl.Size = new System.Drawing.Size(51, 23);
            this.wholeGallonslbl.TabIndex = 15;
            // 
            // Program1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(554, 430);
            this.Controls.Add(this.wholeGallonslbl);
            this.Controls.Add(this.gallonsToBuylbl);
            this.Controls.Add(this.paintMinlbl);
            this.Controls.Add(this.resultscalculatedbtn);
            this.Controls.Add(this.coatNumbertxt);
            this.Controls.Add(this.windowNumbertxt);
            this.Controls.Add(this.doorNumbertext);
            this.Controls.Add(this.wallHeighttxt);
            this.Controls.Add(this.wallLengthtxt);
            this.Controls.Add(this.gallonsMinlbl);
            this.Controls.Add(this.coatNumberlbl);
            this.Controls.Add(this.windowNumberlbl);
            this.Controls.Add(this.doorNumberlbl);
            this.Controls.Add(this.wallHeightlbl);
            this.Controls.Add(this.lengthTotallbl);
            this.Name = "Program1";
            this.Text = "Program1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lengthTotallbl;
        private System.Windows.Forms.Label wallHeightlbl;
        private System.Windows.Forms.Label doorNumberlbl;
        private System.Windows.Forms.Label windowNumberlbl;
        private System.Windows.Forms.Label coatNumberlbl;
        private System.Windows.Forms.Label gallonsMinlbl;
        private System.Windows.Forms.TextBox wallLengthtxt;
        private System.Windows.Forms.TextBox wallHeighttxt;
        private System.Windows.Forms.TextBox doorNumbertext;
        private System.Windows.Forms.TextBox windowNumbertxt;
        private System.Windows.Forms.TextBox coatNumbertxt;
        private System.Windows.Forms.Button resultscalculatedbtn;
        private System.Windows.Forms.Label paintMinlbl;
        private System.Windows.Forms.Label gallonsToBuylbl;
        private System.Windows.Forms.Label wholeGallonslbl;
    }
}

