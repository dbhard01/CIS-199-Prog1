﻿// B1773
// Program 1
// September 26 2017
// CIS 199-75-4178
//This assignment explores the use of variables and simple arithmetic
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1f
{
    public partial class Program1 : Form
    {
        public Program1()
        {
            InitializeComponent();
        }
         // Calculate and display minimum and whole ammount of paint required
        private void resultscalculatedbtn_Click(object sender, EventArgs e)
        {
            double lengthTotal; // Total lentgth of the walls
            double wallHeight; // Wall height
            const double DOOR_FT = 20; //named constant for the feet of the door
            const double WINDOW_SQFT = 15; // named constant for the square feet of the window.
            int coatsDesired; // number of coats required
            const double PAINT_COVERAGE = 350; // named constant for the suare feet the paint is supposed to cover.
            int doorNumber; // number of doors 
            int windowNumber; // number of windows
            double minGallons; // the lowest number of gallons you need to cover the walls.
            int gallonsToBuy; // The number of whole gallons of paint to buy to have enough paint.
            double roughNumberOfSqft; // number from multipling the total length  and total height of the walls.
            double numberOfSqftPerCoat; // number from subtracting the number of doors and windows from the roughNumberOfSqft
            double totalDoorNumber; // the number from multipling the number of doors by the DOOR_FT. 
            double totalWindowNumber; // the number from multipling the number of windows by the WINDOW_SQFT.
            double totalDoorWindowFt; // the number from adding the totalDoorNumber and totalWindowNumber.
            double totalSqFt; // number from multiplying thenumerOfSqft and coatsDesired;
            


            // Parse the input
            lengthTotal = double.Parse(wallLengthtxt.Text);
            wallHeight = double.Parse(wallHeighttxt.Text);
            coatsDesired = int.Parse(coatNumbertxt.Text);
            doorNumber = int.Parse(doorNumbertext.Text);
            windowNumber = int.Parse(windowNumbertxt.Text);


            // Begin calculations
            roughNumberOfSqft = wallHeight * lengthTotal;
            totalDoorNumber = doorNumber * DOOR_FT;
            totalWindowNumber = windowNumber * WINDOW_SQFT;
            totalDoorWindowFt = totalDoorNumber + totalWindowNumber;
            numberOfSqftPerCoat = roughNumberOfSqft - totalDoorWindowFt;
            totalSqFt = numberOfSqftPerCoat * coatsDesired;
            minGallons = totalSqFt / PAINT_COVERAGE;
            gallonsToBuy = (int)Math.Ceiling(minGallons);


            // Output
            paintMinlbl.Text = $"{minGallons:f1}";
           wholeGallonslbl.Text = $"{gallonsToBuy}";


            
             

            



            








        }
    }
}
